--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg120+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hlasovani; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hlasovani (
    id bigint NOT NULL,
    ipadresa inet NOT NULL,
    useragent character varying NOT NULL,
    obor character varying NOT NULL,
    cas bigint NOT NULL
);


ALTER TABLE public.hlasovani OWNER TO postgres;

--
-- Name: hlasovani_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.hlasovani ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.hlasovani_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: hlasy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hlasy (
    ucitel character varying(20) NOT NULL,
    hlasovani bigint NOT NULL,
    pozitivni boolean DEFAULT true NOT NULL
);


ALTER TABLE public.hlasy OWNER TO postgres;

--
-- Name: ucitele; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ucitele (
    jmeno character varying NOT NULL,
    gdpr boolean DEFAULT false NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE public.ucitele OWNER TO postgres;

--
-- Name: zpravy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.zpravy (
    id bigint NOT NULL,
    ucitel character varying NOT NULL,
    text text NOT NULL,
    cas bigint NOT NULL,
    useragent character varying NOT NULL,
    ipadresa inet NOT NULL
);


ALTER TABLE public.zpravy OWNER TO postgres;

--
-- Name: zpravy_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.zpravy ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.zpravy_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: hlasovani hlasovani_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hlasovani
    ADD CONSTRAINT hlasovani_pk PRIMARY KEY (id);


--
-- Name: ucitele ucitele_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ucitele
    ADD CONSTRAINT ucitele_pk PRIMARY KEY (jmeno);


--
-- Name: ucitele ucitele_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ucitele
    ADD CONSTRAINT ucitele_unique UNIQUE (jmeno);


--
-- Name: ucitele ucitele_unique_1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ucitele
    ADD CONSTRAINT ucitele_unique_1 UNIQUE (uuid);


--
-- Name: zpravy zpravy_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zpravy
    ADD CONSTRAINT zpravy_pk PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

